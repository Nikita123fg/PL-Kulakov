import json
import tkinter as tk
from tkinter import messagebox

def save_fixed_info():
    repo_name = entry.get()
    
    if not repo_name:
        messagebox.showwarning("Внимание", "Введите имя репозитория!")
        return

    result = {
        'company': None,
        'created_at': '2015-08-03T17:55:43Z',
        'email': None,
        'id': 13629408,
        'name': repo_name,
        'url': f'https://api.github.com/users/{repo_name}'
    }
    
    with open('variant_info.json', 'w') as json_file:
        json.dump(result, json_file, indent=4)
    
    messagebox.showinfo("Успех", "Данные сохранены в variant_info.json")

root = tk.Tk()
root.title("Сохранение информации")
root.geometry("300x150")

entry = tk.Entry(root)
entry.pack(pady=20)

button = tk.Button(root, text="Сохранить", command=save_fixed_info)
button.pack(pady=10)

root.mainloop()
